from quickstart_django import quickstart_django

quickstart_django.quickstart_django()